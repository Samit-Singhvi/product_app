import axios from "axios";
import React from "react";
import toast, { Toaster } from "react-hot-toast";
import { Form, useNavigate } from "react-router-dom";

export default function ProductTile({
  id,
  name,
  image,
  price,
  description,
  ratings,
  getProductList,
}) {
  const headers = {
    Authorization: sessionStorage.getItem("Authorization"),
  };
  const navigate = useNavigate();

  function deleteHandler(event) {
    axios
      .delete(`http://127.0.0.1:5000/product/${id}`, {
        headers: headers,
      })
      .then((res) => {
        if (res.data.errorCode === 1) {
          toast.error(res.data.errorMessage, {
            style: {
              borderRadius: "10px",
              background: "#333",
              color: "#fff",
            },
          });
        } else {
          toast.success(
            `${name} product deleted successfully !! Happy to serve you`,
            {
              style: {
                borderRadius: "10px",
                background: "#333",
                color: "#fff",
              },
            }
          );
          getProductList();
        }
      });
  }

  function productClickHandler(event) {
    const productDetails = {
      name: name,
      ratings: ratings,
      description: description,
      price: price,
      image: image,
    };
    console.log(productDetails);
    navigate("/details", { state: productDetails });
  }

  function buyNowHandler(event) {
    let paymentConfirm = prompt("Have you made the payment ?");
    const formData = new FormData();
    formData.append("quantity", 1);
    formData.append("payment_confirm", paymentConfirm);
    let api_url = `http://127.0.0.1:5000/product/buynow/${id}`;
    axios
      .post(api_url, formData, {
        headers: headers,
      })
      .then((res) => {
        if (res.data.errorCode === 1) {
          toast.error(res.data.errorMessage, {
            style: {
              borderRadius: "10px",
              background: "#333",
              color: "#fff",
            },
          });
        } else {
          toast.success(
            `${name} product purchased successful !! Happy to serve you`,
            {
              style: {
                borderRadius: "10px",
                background: "#333",
                color: "#fff",
              },
            }
          );
        }
      });
  }

  function addToCartHandler(event) {
    let api_url = `http://127.0.0.1:5000/product/addtocart/${id}`;

    axios
      .post(
        api_url,
        {},
        {
          headers: headers,
        }
      )
      .then((res) => {
        if (res.data.errorCode === 1) {
          toast.error(res.data.errorMessage, {
            style: {
              borderRadius: "10px",
              background: "#333",
              color: "#fff",
            },
          });
        } else {
          toast.success(`${name} added to Cart for you`, {
            style: {
              borderRadius: "10px",
              background: "#333",
              color: "#fff",
            },
          });
        }
      });
  }
  return (
    <>
      <div className="card h-100 m-1 p-3 shadow">
        <Toaster position="top-center" reverseOrder={false} />
        <img
          src={`${process.env.PUBLIC_URL}/images/${image.split("/").pop()}`}
          width="200px"
          height="150px"
          onClick={productClickHandler}
        ></img>
        <center>{name}</center>
        <center>{price}</center>
        <button
          type="button"
          name="add-to-cart"
          className="btn btn-dark"
          onClick={addToCartHandler}
          style={{ display: "block", margin: "0 auto", width: "150px" }}
        >
          Add to Cart
        </button>
        <button
          type="button"
          name="buy-now"
          className="btn btn-dark"
          onClick={buyNowHandler}
          style={{ display: "block", margin: "0 auto", width: "150px" }}
        >
          Buy Now
        </button>
      </div>
    </>
  );
}
