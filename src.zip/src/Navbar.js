import React from "react";
import { Link } from "react-router-dom";
import "./Navbar.css";

export default function Navbar({ profileHandler, logoutHandler }) {
  return (
    <nav className="navbar">
      <Link to="/" className="navbar-logo">
        Flipmart
      </Link>
      <div className="navbar-buttons">
        <button
          type="button"
          className="btn btn-primary"
          onClick={profileHandler}
        >
          Profile
        </button>
        <button
          type="button"
          className="btn btn-primary"
          onClick={logoutHandler}
          name="logout-button"
        >
          Logout
        </button>
      </div>
    </nav>
  );
}
