import React from "react";
import "./Product_details.css";
import { useLocation } from "react-router-dom";

export default function ProductDetails() {
  const location = useLocation();
  const productDetails = location.state;
  console.log("/////////////", productDetails);

  return (
    <div className="height d-flex justify-content-center align-items-center">
      <div className="card p-3">
        <div className="d-flex justify-content-between align-items-center ">
          <div className="mt-2">
            <h4 className="text-uppercase">{productDetails.name}</h4>
            <div className="mt-5">
              <h5 className="text-uppercase mb-0">{productDetails.name}</h5>
              <div className="d-flex flex-row user-ratings">
                <div className="ratings">
                  <i className="fa fa-star" />
                  <i className="fa fa-star" />
                  <i className="fa fa-star" />
                  <i className="fa fa-star" />
                </div>
                <h6 className="text-muted ml-1">{productDetails.ratings}/5</h6>
              </div>
            </div>
          </div>
          <div className="image">
            <img
              src={`${process.env.PUBLIC_URL}/images/${productDetails.image
                .split("/")
                .pop()}`}
              width={"200px"}
              height={"150px"}
            />
          </div>
        </div>
        <div className="d-flex justify-content-between align-items-center mt-2 mb-2">
          <span>Available colors</span>
          <div className="colors">
            <span />
            <span />
            <span />
            <span />
          </div>
        </div>
        <p>{productDetails.description}</p>
        <button className="btn btn-danger">Add to cart</button>
      </div>
    </div>
  );
}
